import requests

#Solicitando nomes.
def gen_nome():
    nome = input("Digite o seu nome: ").strip()
    link = f"https://api.genderize.io/?name={nome}"

   #Respostas após digitar o nome.
    try:
        resposta = requests.get(link)
        dados = resposta.json()

        if 'gender' in dados and dados['gender'] is not None:
            print(f"\nNome: {dados['name']}")
            print(f"Gênero: {dados['gender']}")
            print(f"Probabilidade: {dados['probability']}")
            print(f"Contagem: {dados['count']}")
        else:
            print(f"\nNome vazio ou não encontrando '{nome}'.")
    except Exception as e:
        print(f"Problemas de conexão ou erros da API: {e}")

#Saída do resultado
gen_nome()