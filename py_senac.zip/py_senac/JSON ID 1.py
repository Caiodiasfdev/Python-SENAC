import requests
import json

def buscar_id():
    url = "https://jsonplaceholder.typicode.com/users"
    do_url = requests.get(url)

    digite = input("Digite o ID de usuário: ")

    if do_url.status_code == 200:
        usuarios = do_url.json()
        
        nome = usuarios["name"]
        username = usuarios["username"]
        email = usuarios["email"]
        empresa = usuarios["company"]["name"]
        
        print(f"Nome: {nome}")
        print(f"Username: {username}")
        print(f"Email: {email}")
        print(f"Empresa: {empresa}")
    else:
        print(f"Erro na requisição: {do_url.status_code}")

buscar_id()