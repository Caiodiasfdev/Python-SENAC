frutas = ["banana", "maça", "uva", "morango","laranja"]
frutas.append ("melancia")

print(frutas)