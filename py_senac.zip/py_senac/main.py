import requests
import json

#Início pela url
url = "https://jsonplaceholder.typicode.com/users/1"

#Fazendo requests.get
response = requests.get(url)

if response.status_code == 200:
    data = response.json()

    #Extraindo informações
    nome = data["name"]
    username = data["username"]
    email = data["email"]
    empresa = data["company"]["name"]

    print(f"Nome: {nome}")
    print(f"Username: {username}")
    print(f"Email: {email}")
    print(f"Empresa: {empresa}")
else:
    print(f"Erro na requisição: {response.status_code}")

#Saída final das Informações
print(data)